#define _MQTT_BROKER "technophyscal.cloud.shiftr.io"     //Nom FQDN (réseau) du service broker _MQTT
#define _MQTT_PORT 1883
#define _MQTT_USERNAME "technophyscal"   //Le login/instance du service que nous utilisons
#define _MQTT_TOKEN "UGTd9Ouws2kDv7Kr"      //Le token qui vous a été attribué
#define _MQTT_DEVICEID "fstg"   //Nom de votre engin, doit être unique pour l'instance
#define _MQTT_PUBLISH_TOPIC "fstg-pub"
#define _MQTT_SUBSCRIBE_TOPIC "FSTG-sub"
#define _ETHERNET_MAC {0x24, 0x6f, 0x28, 0x01, 0x01, 0xae}
