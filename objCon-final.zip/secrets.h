#pragma once

#define MQTT_clientId "devis-device"
#define MQTT_userName "technophyscal"
#define MQTT_password "012345"
#define MQTT_HOST "technophys-tb.claurendeau.qc.ca"
#define MQTT_PORT 1883
#define MQTT_SUBSCRIBE_TOPIC "v1/devices/me/rpc/request/+"
#define MQTT_PUBLISH_TOPIC "v1/devices/me/telemetry"

// #define WIFI_MAC { 0x24, 0x6f, 0x28, 0x01, 0x01, 0xB0 }

#define SYS_ID 90909

#define NTP_SERVER "pool.ntp.org"
#define NTP_gmtOffset_sec 0
#define NTP_daylightOffset_sec 3600

const char * NETWORKS[][2] = {
    // {"MQTT", ""},
    // {"Invite", ""},
    // {"CAL-Net", ""},
    {"zeppy", "Newera2012"}
};