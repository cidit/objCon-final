# objCon-final
 
23/04/2025

## thingsboard access

- host: http://technophys-tb.claurendeau.qc.ca:8080/login
- user: etuH24G0201@claurendeau.qc.ca
- pass: etuH24G0201

## mqtt shit

{clientId:"devis-device",userName:"technophyscal",password:"012345"}
